const grid = document.getElementById("grid");
const movesEl = document.getElementById("moves");
const resetBtn = document.getElementById("reset");

const emojis = ["🎮","🎮","🚀","🚀","🧠","🧠","🔥","🔥","💻","💻","⚡","⚡","🎯","🎯","👑","👑"];
let first = null, second = null, lock = false, moves = 0;

function shuffle(array){ return array.sort(()=>0.5-Math.random()) }

function createBoard(){
  grid.innerHTML = "";
  moves = 0; movesEl.textContent = 0;
  shuffle(emojis).forEach(emoji => {
    const card = document.createElement("div");
    card.className = "card";
    card.dataset.emoji = emoji;
    card.addEventListener("click", flipCard);
    grid.appendChild(card);
  });
}

function flipCard(){
  if(lock || this.classList.contains("flipped")) return;
  this.textContent = this.dataset.emoji;
  this.classList.add("flipped");

  if(!first){ first = this; return; }
  second = this; moves++; movesEl.textContent = moves; lock = true;

  if(first.dataset.emoji === second.dataset.emoji){
    first.classList.add("matched"); second.classList.add("matched");
    first = second = null; lock = false;
    if(document.querySelectorAll(".matched").length === 16){
      setTimeout(()=> alert(`You won in ${moves} moves! Winning is everything.`), 300);
    }
  } else {
    setTimeout(()=>{
      first.textContent = ""; second.textContent = "";
      first.classList.remove("flipped"); second.classList.remove("flipped");
      first = second = null; lock = false;
    }, 800);
  }
}

resetBtn.addEventListener("click", createBoard);
createBoard();