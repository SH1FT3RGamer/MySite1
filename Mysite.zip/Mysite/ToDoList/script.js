const input = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const list = document.getElementById("taskList");
const countEl = document.getElementById("count");

let taskCount = 0;

function updateCount(){
  countEl.textContent = `${taskCount} tasks`;
}

addBtn.addEventListener("click", addTask);

input.addEventListener("keypress", (e) => {
  if(e.key === "Enter") addTask();
});

function addTask(){
  const text = input.value.trim(); 
  if(!text) return; 

  taskCount++;
  updateCount();

  const li = document.createElement("li");
  li.textContent = text;

  const delBtn = document.createElement("button");
  delBtn.textContent = "X";
  delBtn.className = "delete";

  li.addEventListener("click", () => {
    li.classList.toggle("done"); 
  });

  delBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    li.remove();
    taskCount--;
    updateCount();
  });


  li.appendChild(delBtn);
  list.appendChild(li);

  input.value = ""; 
}