let count = 0; 

function update() {
  document.getElementById("count").innerText = count;
  
  if (count > 0) document.body.style.background = "#0d70e9";
  else if (count < 0) document.body.style.background = "#971a1a";
  else document.body.style.background = "#111";
}

function increase() { count++; update(); }
function decrease() { count--; update(); }
function reset() { count = 0; update(); }
