function setMood(mood) {
  let heading = document.getElementById("heading");
  let message = document.getElementById("message");

  if (mood === "happy") {
    document.body.style.background = "#FFF176"; // sunny yellow
    heading.innerText = "Feeling Good! 😊";
    message.innerText = "Keep that energy! Today is yours.";
  } 
  else if (mood === "neutral") {
    document.body.style.background = "#B0BEC5"; // grey chill
    heading.innerText = "Just Vibing 😐";
    message.innerText = "Neutral is okay. Rest and reset.";
  } 
  else if (mood === "angry") {
    document.body.style.background = "#EF5350"; // red
    heading.innerText = "Breathe... 😡";
    message.innerText = "It's okay to be angry. Take a couple of deep breaths.";
  }
}