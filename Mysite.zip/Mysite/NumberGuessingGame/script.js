let secretNumber = Math.floor(Math.random() * 100) + 1; // 1-100
let attempts = 0;

const input = document.getElementById("guessInput");
const btn = document.getElementById("guessBtn");
const message = document.getElementById("message");
const attemptsEl = document.getElementById("attempts");
const resetBtn = document.getElementById("resetBtn");

btn.addEventListener("click", () => {
  const guess = Number(input.value); // turn text to number

  if(!guess){ // if empty
    message.textContent = "Enter a number bro 😭";
    return;
  }

  attempts++;
  attemptsEl.textContent = `Attempts: ${attempts}`;

  if(guess === secretNumber){
    message.textContent = `You got it! It was ${secretNumber} 🎉`;
    message.style.color = "#00ff88";
    resetBtn.style.display = "inline-block";
    btn.style.display = "none";
  } 
  else if(guess < secretNumber){
    message.textContent = "Too low! Go higher ⬆️";
    message.style.color = "#ff3b3b";
  }
  else{
    message.textContent = "Too high! Go lower ⬇️";
    message.style.color = "#ffcc00";
  }

  input.value = ""; // clear input
});

resetBtn.addEventListener("click", () => {
  secretNumber = Math.floor(Math.random() * 100) + 1;
  attempts = 0;
  attemptsEl.textContent = "Attempts: 0";
  message.textContent = "I'm thinking of a new number...";
  message.style.color = "white";
  btn.style.display = "inline-block";
  resetBtn.style.display = "none";
});