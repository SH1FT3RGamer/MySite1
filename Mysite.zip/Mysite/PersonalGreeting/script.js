function sayHello() {
    let name=prompt("What is your name?");
    
    if (name === null || name ===""){name=" Friend"
    }

    document.getElementById("message").innerText= "Hello" + name + "! Welcome to Coding";
    document.getElementById("title").innerText=  "Nice to meet you, " + name;
    document.body.style.background = "powderblue";
}