
const quotes = [
  { text: "The night is where I rebuild.", author: "N1GHTC0D3" },
  { text: "Code. Sleep. Repeat.", author: "Average Programmer" },
  { text: "Bugs are just undocumented features.", author: "Every Dev Ever" },
  { text: "First it doesn't work, then it works.", author: "JavaScript" },
  { text: "In this world, winning is everything", author: "Ayanokoji Kiyotaka" },
  { text: "Every day is a chance to start a new chapter", author: "Unknown"}
];

const quoteEl = document.getElementById("quote");
const authorEl = document.getElementById("author");
const btn = document.getElementById("newQuote");

btn.addEventListener("click", () => {
  
  const randomIndex = Math.floor(Math.random() * quotes.length);

  const randomQuote = quotes[randomIndex];

  quoteEl.textContent = `"${randomQuote.text}"`;
  authorEl.textContent = `- ${randomQuote.author}`;
});