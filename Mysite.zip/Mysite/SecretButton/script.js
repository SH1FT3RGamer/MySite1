let clicks = 0;
const btn = document.getElementById("secretBtn");
const heading = document.getElementById("heading");
const countText = document.getElementById("counter");
const body = document.body;

// This runs every time you click
btn.addEventListener("click", () => {
  clicks++;
  countText.textContent = `Clicks: ${clicks}`;

  if (clicks === 1) {
    // First click
    btn.textContent = "Bruh, I said DON'T click me 😭";
    heading.textContent = "Why did you click it?";
    body.style.background = "#ff3b3b";
  } 
  else if (clicks === 2) {
    // Second click - random color
    btn.textContent = "Okay you are being annoying now";
    heading.textContent = "Still clicking? Bet.";
    // Random color trick
    const randomColor = "#" + Math.floor(Math.random()*16777215).toString(16);
    body.style.background = randomColor;
  }
  else if (clicks === 3) {
    // Third click - button starts running away
    btn.textContent = "You can't catch me now";
    heading.textContent = "Try to catch it if you can 😈";
    btn.addEventListener("mouseover", runAway); // now it runs when you hover
  }
  else if (clicks === 4) {
    btn.textContent = "OKAY OKAY YOU WIN";
    heading.textContent = "N1GHTC0D3 is dangerous now 💀";
    body.style.background = "#0066ff";
  }
  else {
    // 5+ clicks
    btn.textContent = `Stop, you've clicked ${clicks} times!`;
    heading.textContent = "You have too much time 😂";
  }
});

// This function moves the button to a random spot
function runAway() {
  const x = Math.random() * (window.innerWidth - btn.offsetWidth);
  const y = Math.random() * (window.innerHeight - btn.offsetHeight);
  
  btn.style.left = `${x}px`;
  btn.style.top = `${y}px`;
  btn.style.transform = "translate(0, 0)"; // remove centering
}