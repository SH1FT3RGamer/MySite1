const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");

let current = ""; // what you see on screen

buttons.forEach(btn => {
  btn.addEventListener("click", () => {
    const value = btn.textContent;

    if(btn.classList.contains("num") || btn.classList.contains("op")){
      // If number or operator, add to string
      current += value;
      display.value = current;
    }
    else if(btn.classList.contains("clear")){
      // C = clear everything
      current = "";
      display.value = "";
    }
    else if(btn.classList.contains("del")){
      // DEL = delete last character
      current = current.slice(0, -1);
      display.value = current;
    }
    else if(btn.classList.contains("equal")){
      // = calculate
      try {
       
        current = String(Function('"use strict"; return (' + current + ')')());
        display.value = current;
      } catch {
        display.value = "Error";
        current = "";
      }
    }
  });
});